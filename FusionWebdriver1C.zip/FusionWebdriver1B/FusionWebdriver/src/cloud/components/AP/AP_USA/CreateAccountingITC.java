package cloud.components.AP.AP_USA;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import itc.framework.BaseTest;

public class CreateAccountingITC extends BaseTest{


	public static String Ledger;
	public static String SubledgerApplication;
//
	public static String ProcessCategory;
	public static String EndDate;
	public static String AccountingMode;
	public static String ProcessEvents;
	public static String ReportStyle;
	public static String TransferToGeneralLedger;
	public static String PostInGeneralLedger;
	public static String JournalBatch;
	public static String IncludeUserTransactionIndentifier;
	

	private static void run() throws Exception  {
		Thread.sleep(1000);
//		clickElement(By.xpath("//span[contains(text(),'Invoices')]")); //Invoices
		clickElement(By.linkText("Invoices")); 
		clickElement(By.xpath("//*[contains(@id, 'FndTasksList::icon')]")); //Task button
		clickElement(By.linkText("Create Accounting")); //Create Accounting link
		clickElement(By.xpath("//*[contains(@id,'SubledgerApplicationAttr::content')]"));
		clickElement(By.xpath("//option[contains(text(),'Payables')]")); //Payables
		setElementText(By.xpath("//*[contains(@id,'LedgerAttr::content')]"), Ledger); //ITC USA PL
		browser.findElement(By.xpath("//*[contains(@id,'LedgerAttr::content')]")).sendKeys(Keys.TAB);
		clickElement(By.xpath("//*[contains(@id,'requestBtns:submitButton')]"));
		//clickElement(By.xpath("//*[contains(@id,'confirmSubmitDialog::ok')]"));
		String s=browser.findElement(By.cssSelector("span[style='font-weight:normal'] label")).getText();
		
		String processId=s.replaceAll("[^0-9]", "");
		Thread.sleep(1000);
		System.out.println("Process id is: "+ processId);
		
		//int n1=Integer.parseInt(browser.findElement(By.cssSelector("span[style='font-weight:normal']")).getText());
		//System.out.println("Process id is: "+Integer.parseInt(browser.findElement(By.cssSelector("span[style='font-weight:normal']")).getText()));
		
		clickElement(By.xpath("//*[contains(@id,'confirmSubmitDialog::ok')]"));
		//clickElement(By.cssSelector["svg[aria-label=\"Navigator\"]"]);
		//clickElement(By.cssSelector("svg[aria-label=\\\"Navigator\\\"]"));
		clickElement(By.cssSelector("path[d=\"M3 7H25M3 14H25M3 21H25\"]"));
		Thread.sleep(5000);
		//clickElement(By.cssSelector("div[title=\"Tools\"] div:last-child"));
		//Thread.sleep(5000);
		clickElement(By.xpath("//a[@id='_FOpt1:_UISnvr:0:nv_itemNode_tools_scheduled_processes_fuse_plus']//*[name()='svg']"));
		Thread.sleep(5000);
		clickElement(By.cssSelector("a[title=\"Expand Search\"]"));
		Thread.sleep(5000);
		browser.findElement(By.xpath("//input[@id='_FOpt1:_FOr1:0:_FONSr2:0:_FOTsr1:0:pt1:srRssdfl:value10::content']")).sendKeys(processId);
		clickElement(By.xpath("(//td)[115]"));
	    String s1=browser.findElement(By.cssSelector("td[style=\"width:150px;\"]")).getText();
		Assert.assertEquals(s1, "success");
		while(s1!="Succeeded")
		{
			clickElement(By.xpath("(//td)[115]"));
			Thread.sleep(5000);
			System.out.println("refreshing the search");
		}
		
		
		
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE5::content')]"), ProcessCategory);
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE6::content')]"), EndDate);
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE8::content')]"), AccountingMode);
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE9::content')]"), ProcessEvents);
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE10::content')]"), ReportStyle);
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE11::content')]"), TransferToGeneralLedger);
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE12::content')]"), PostInGeneralLedger);
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE13::content')]"), JournalBatch);
		//setElementText(By.xpath("//*[contains(@id,'ATTRIBUTE15::content')]"), IncludeUserTransactionIndentifier);
		
	}

	public static void run(int iterations) throws Exception{
		initComponent();
		for(int i=0;i<iterations;i++)
		{
			iteration=i;
			popluateParams(CreateAccountingITC.class);
			run();
		}
	}
	
	

}
