package cloud.tests.HCM.CoreHR_ITC;

public class ChangingMaritalStatusITC_Test {

}
