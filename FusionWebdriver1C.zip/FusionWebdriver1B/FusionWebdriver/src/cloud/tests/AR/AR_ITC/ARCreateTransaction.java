package cloud.tests.AR.AR_ITC;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

//Testcase - Create AR Transaction and appply hold

public class ARCreateTransaction {
	

  @DataProvider(name = "data")
  public void data(){
//	  String url = "https://ucf5-fap0487-fs.oracledemos.com";
//		String userid = "casey.brown";
//		String pwd = "CrU49333";
  }
  
  @BeforeTest
  public void init()
  {
	  
  }
  
  @Test
  public void run() {
	  
  }
  
  @AfterTest
  public void finish()
  {
	  
  }
}
